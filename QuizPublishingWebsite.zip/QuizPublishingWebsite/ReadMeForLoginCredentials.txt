Admin (Username and Password) Login: 
-> King, Masterkey123.
-> Queen, Masterkey123.

Teacher (Username and Password) Login: 
-> Anwar, Anwar02.
-> Joshua, Joshie9099.

Student (Username and Password) Login: 
-> hogrider, Hogrider123.
-> Najib, Najib123.
-> marshall, Marshall123.

**sir you can create your own profile, or change password using Admin accounts
**more profiles in database with password hashed