<header>
        <a href="stu-home.php" class="logo" title="Morning Quiznos"><img src="media/sun.png" alt="Morning" width="40px" height="40px"></a>
        <a href="stu-home.php" class="morning"><h1 class="header">MORNING QUIZNOS</h1></a>
        <div class="header">
            <nav class="header">
                <a href="stu-home.php#RK" class="header">Ranked Assessment</a>
                <a href="stu-home.php#subject" class="header">Subjects</a>
            </nav>
            <a href="viewStudentProfile.php" class="profile" title="Profile">
                <div class="profileHeaderContainer">
                    <img id="headerProfile" src="<?php echo $_SESSION['photo']?>" alt="Profile Picture">
                </div>
            </a>
        </div>
</header>
