// function addTrophyImage(source, altText) {
//     const td = document.getElementById("trophyTable").getElementsByTagName("td");
    
//     for (let i = 0; i <= 7; i++) {
//         let img = document.createElement("img");
//         img.src = source;
//         img.alt = altText;
//         img.className = "trophy";
//         td[i].appendChild(img);
//     }
// }
  
// addTrophyImage("media/trophy.png", "Trophy");


// function setProfile() {
//     let img = document.createElement("img");
//     img.src = source;
//     img.alt = altText;
//     img.className = "trophy";
//     td[i].appendChild(img);
// }
